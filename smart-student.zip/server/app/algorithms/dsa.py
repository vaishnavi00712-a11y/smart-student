"""
DSA Module for Smart Student Companion Backend
Implements Searching, Sorting, Priority Queue, Graph Traversal, and RAG Cosine Similarity.
"""
import math
import heapq
import time
from typing import List, Dict, Any, Tuple, Optional

# 1. SORTING: Merge Sort
def merge_sort(items: List[Any], key_fn) -> Tuple[List[Any], Dict[str, Any]]:
    start_time = time.perf_counter()
    comparisons = [0]

    def merge(left, right):
        result = []
        i = j = 0
        while i < len(left) and j < len(right):
            comparisons[0] += 1
            if key_fn(left[i]) <= key_fn(right[j]):
                result.append(left[i])
                i += 1
            else:
                result.append(right[j])
                j += 1
        result.extend(left[i:])
        result.extend(right[j:])
        return result

    def sort(arr):
        if len(arr) <= 1:
            return arr
        mid = len(arr) // 2
        return merge(sort(arr[:mid]), sort(arr[mid:]))

    sorted_list = sort(items)
    elapsed = (time.perf_counter() - start_time) * 1000
    metrics = {
        "algorithm": "Merge Sort",
        "best_case": "O(n log n)",
        "average_case": "O(n log n)",
        "worst_case": "O(n log n)",
        "space_complexity": "O(n)",
        "execution_time_ms": round(elapsed, 3),
        "comparisons": comparisons[0]
    }
    return sorted_list, metrics

# 2. SEARCHING: Binary Search
def binary_search(sorted_items: List[Any], target: str, key_fn) -> Tuple[Optional[Any], int, Dict[str, Any]]:
    start_time = time.perf_counter()
    low = 0
    high = len(sorted_items) - 1
    steps = 0
    target_lower = target.lower()

    while low <= high:
        steps += 1
        mid = (low + high) // 2
        mid_val = key_fn(sorted_items[mid]).lower()
        if mid_val == target_lower:
            elapsed = (time.perf_counter() - start_time) * 1000
            metrics = {
                "algorithm": "Binary Search",
                "best_case": "O(1)",
                "average_case": "O(log n)",
                "worst_case": "O(log n)",
                "space_complexity": "O(1)",
                "steps": steps,
                "execution_time_ms": round(elapsed, 3)
            }
            return sorted_items[mid], mid, metrics
        elif mid_val < target_lower:
            low = mid + 1
        else:
            high = mid - 1

    elapsed = (time.perf_counter() - start_time) * 1000
    metrics = {
        "algorithm": "Binary Search",
        "best_case": "O(1)",
        "average_case": "O(log n)",
        "worst_case": "O(log n)",
        "space_complexity": "O(1)",
        "steps": steps,
        "execution_time_ms": round(elapsed, 3)
    }
    return None, -1, metrics

# 3. PRIORITY QUEUE / MAX HEAP (Assignment Urgency)
class AssignmentPriorityQueue:
    def __init__(self):
        self.heap = [] # Stores (-urgency_score, item)

    def insert(self, item: Any, score: float):
        heapq.heappush(self.heap, (-score, item))

    def extract_max(self) -> Optional[Any]:
        if not self.heap:
            return None
        neg_score, item = heapq.heappop(self.heap)
        return {"item": item, "priorityScore": -neg_score}

    def to_sorted_list(self) -> List[Dict[str, Any]]:
        temp = list(self.heap)
        result = []
        while self.heap:
            neg_score, item = heapq.heappop(self.heap)
            result.append({"item": item, "priorityScore": -neg_score})
        self.heap = temp
        return result

# 4. ATTENDANCE PREDICTION ALGORITHM
def attendance_prediction(present: int, total: int, target_percent: float = 75.0) -> Dict[str, Any]:
    if total == 0:
        return {"current_percentage": 100.0, "classes_needed": 0, "classes_can_miss": 0, "status": "Safe"}

    current_pct = round((present / total) * 100, 2)
    classes_needed = 0
    if current_pct < target_percent:
        # classes_needed = ceil((P * T - 100 * A) / (100 - P))
        num = (target_percent * total) - (100 * present)
        den = 100 - target_percent
        classes_needed = math.ceil(num / den) if den > 0 else 0

    classes_can_miss = 0
    if current_pct >= target_percent:
        classes_can_miss = math.floor((100 * present - target_percent * total) / target_percent)

    status = "Shortage" if current_pct < 75 else ("Warning" if current_pct < 80 else "Safe")
    return {
        "current_percentage": current_pct,
        "classes_needed": max(0, classes_needed),
        "classes_can_miss": max(0, classes_can_miss),
        "status": status
    }

# 5. COSINE SIMILARITY (RAG)
def cosine_similarity(text_a: str, text_b: str) -> float:
    def tokenize(text):
        return [w.lower() for w in text.split() if len(w) > 2]

    tokens_a = tokenize(text_a)
    tokens_b = tokenize(text_b)
    if not tokens_a or not tokens_b:
        return 0.0

    vocab = set(tokens_a).union(set(tokens_b))
    vec_a = {word: tokens_a.count(word) for word in vocab}
    vec_b = {word: tokens_b.count(word) for word in vocab}

    dot_product = sum(vec_a[w] * vec_b[w] for w in vocab)
    norm_a = math.sqrt(sum(val ** 2 for val in vec_a.values()))
    norm_b = math.sqrt(sum(val ** 2 for val in vec_b.values()))

    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot_product / (norm_a * norm_b)
