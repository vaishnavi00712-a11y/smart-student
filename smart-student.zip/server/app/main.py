"""
Smart Student Companion - FastAPI Backend Application
Entrypoint providing OpenAPI 3.0 documentation, CORS, and modular route inclusion.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from server.app.core.config import settings
from server.app.routes.api import router as api_router

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Full-stack student productivity & academic management backend with MongoDB & DSA algorithms",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix=settings.API_V1_STR)

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": settings.PROJECT_NAME}
