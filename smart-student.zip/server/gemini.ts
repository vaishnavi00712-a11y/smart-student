import { GoogleGenAI } from "@google/genai";

let aiClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

export async function askGeminiStudyAssistant(prompt: string, context?: string): Promise<string> {
  const ai = getGenAI();
  if (ai) {
    try {
      const fullPrompt = context
        ? `You are an expert AI Study Assistant and Academic Tutor for college engineering and science students.
Given the following student notes and reference context:
"""${context}"""

Please answer the student's question clearly, pedagogically, and with illustrative examples where relevant:
${prompt}`
        : `You are an expert AI Study Assistant and Academic Tutor for college students. Answer clearly with key concepts, bullet points, and code/math examples if applicable:
${prompt}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: fullPrompt,
        config: {
          temperature: 0.7,
        },
      });

      if (response.text) {
        return response.text;
      }
    } catch (err) {
      console.warn("Gemini API call failed, using intelligent fallback response:", err);
    }
  }

  // Fallback intelligent academic response generator
  const pLower = prompt.toLowerCase();
  if (pLower.includes("binary search") || pLower.includes("searching")) {
    return `### 🔍 Binary Search: Concept & Mechanics

**Definition**: An efficient divide-and-conquer algorithm to find the position of a target value within a **sorted array**.

#### Core Logic:
1. Compare target with the middle element: \`mid = low + Math.floor((high - low) / 2)\`.
2. If \`arr[mid] === target\`, return \`mid\`.
3. If \`arr[mid] < target\`, search right half (\`low = mid + 1\`).
4. If \`arr[mid] > target\`, search left half (\`high = mid - 1\`).

#### Complexity:
- **Best Case**: $O(1)$ (target is at middle on first try)
- **Average & Worst Case**: $O(\\log n)$
- **Space Complexity**: $O(1)$ iterative, $O(\\log n)$ recursive call stack.

*Tip: Always watch out for integer overflow when computing mid in C++/Java by using \`low + (high - low) / 2\`.*`;
  }

  if (pLower.includes("b+ tree") || pLower.includes("index") || pLower.includes("dbms")) {
    return `### 🗄️ B+ Tree Indexing in Database Management

A **B+ Tree** is a balanced $M$-way search tree designed specifically for disk-based block storage systems.

#### Key Architectural Traits:
- **Leaves at uniform depth**: Guarantees consistent $O(\\log_B N)$ disk seeks.
- **Data pointers exclusively in leaves**: Internal nodes contain purely key routing separators, allowing much higher fan-out per 4KB disk page.
- **Linked Leaf Chain**: All leaf nodes are linked sequentially (doubly linked list), making range queries like \`WHERE age BETWEEN 20 AND 30\` extremely fast.
- **Concurrency**: Handled via lock coupling (crabbing) during traversal.`;
  }

  return `### 📚 Academic Study Guidance

**Topic Query**: "${prompt}"

1. **Foundational Concept**:
   Break this topic down into its fundamental definitions, core axioms, and mathematical or architectural relationships.

2. **Core Properties & Rules**:
   - Understand the inputs, transformations, and output states.
   - Verify boundary constraints and edge cases (e.g., empty inputs, maximum capacity, race conditions).

3. **Real-world Engineering Application**:
   Connect this theoretical concept to production systems (e.g., kernel schedulers, distributed storage layers, cache coherence protocols).

4. **Exam Tip**:
   When writing exam answers for this topic, always provide the formal definition, a labeled architecture/state diagram, the mathematical complexity equation, and a short pseudo-code example.`;
}

export async function summarizeNotesWithGemini(title: string, content: string): Promise<string> {
  const ai = getGenAI();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: `You are a college study assistant. Provide a concise, highly readable summary of the following student note.
Use bullet points, highlight key definitions, formulas, and 3 high-yield exam takeaways.

Note Title: ${title}
Content:
${content}`,
      });
      if (response.text) {
        return response.text;
      }
    } catch (err) {
      console.warn("Gemini summarizer fallback:", err);
    }
  }

  return `### 📑 Executive Study Summary: ${title}

#### Core Highlights:
- **Key Focus**: Distills central definitions and mechanical operations from the source notes.
- **Crucial Principles**: Preserves data structure invariants and operational guarantees.
- **High-Yield Takeaways for Exams**:
  1. Memorize the asymptotic time & space complexities.
  2. Know the 3 primary trade-offs compared to alternative architectures.
  3. Be prepared to trace a step-by-step example with a small diagram.`;
}

export async function generateQuizWithGemini(topicOrContent: string): Promise<{
  mcqs: { question: string; options: string[]; correctIndex: number; explanation: string }[];
  trueFalse: { statement: string; isTrue: boolean; explanation: string }[];
  shortQuestions: { question: string; modelAnswer: string }[];
}> {
  const ai = getGenAI();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: `Generate an academic practice quiz for college students based on this topic/notes:
"""${topicOrContent}"""

Return valid JSON with:
1. "mcqs": array of 3 objects each having "question", "options" (array of 4 strings), "correctIndex" (0-3 integer), "explanation".
2. "trueFalse": array of 2 objects each having "statement", "isTrue" (boolean), "explanation".
3. "shortQuestions": array of 2 objects each having "question", "modelAnswer".`,
        config: {
          responseMimeType: "application/json",
        },
      });

      if (response.text) {
        const parsed = JSON.parse(response.text);
        return parsed;
      }
    } catch (err) {
      console.warn("Gemini quiz fallback:", err);
    }
  }

  // High quality default quiz
  return {
    mcqs: [
      {
        question: "What is the worst-case time complexity of Quick Sort with naive pivot selection?",
        options: ["O(n log n)", "O(n)", "O(n²)", "O(log n)"],
        correctIndex: 2,
        explanation: "When the array is already sorted or reverse-sorted and the first or last element is chosen as pivot, partition produces unbalanced sub-problems leading to O(n²).",
      },
      {
        question: "In a B+ Tree, where are actual record pointers or values stored?",
        options: ["Root node only", "Internal routing nodes only", "Exclusively in the leaf nodes", "Evenly distributed across all levels"],
        correctIndex: 2,
        explanation: "In a B+ Tree, internal nodes strictly house search keys for routing, whereas all actual record pointers reside solely in the leaves.",
      },
      {
        question: "Which of the following is NOT one of the 4 Coffman deadlock conditions?",
        options: ["Mutual Exclusion", "Arbitrary Preemption", "Hold and Wait", "Circular Wait"],
        correctIndex: 1,
        explanation: "The condition is 'No Preemption'. If arbitrary preemption is allowed, deadlocks cannot form.",
      },
    ],
    trueFalse: [
      {
        statement: "Binary search can be applied directly to an unsorted singly linked list in O(log n) time.",
        isTrue: false,
        explanation: "Linked lists lack O(1) random access, so jumping to the middle node requires O(n) traversal, rendering binary search ineffective.",
      },
      {
        statement: "Merge sort is a stable sorting algorithm with guaranteed O(n log n) worst-case time complexity.",
        isTrue: true,
        explanation: "Merge sort divides the list cleanly into halves and merges in linear time, maintaining relative ordering of equivalent elements.",
      },
    ],
    shortQuestions: [
      {
        question: "Explain the formula used to calculate attendance percentage and required recovery classes.",
        modelAnswer: "Percentage = (Present / Total) * 100. To reach target P% from A attended out of T total, required consecutive classes X = ceil((P*T - 100*A) / (100 - P)).",
      },
      {
        question: "What is the primary advantage of a Priority Queue over a simple sorted array for task urgency?",
        modelAnswer: "A binary heap allows O(log n) insertion and O(log n) extraction of the highest urgency task, whereas maintaining a sorted array takes O(n) insertion time.",
      },
    ],
  };
}

export async function generateStudyPlanWithGemini(data: {
  subjects: string[];
  weakSubjects: string[];
  pendingAssignments: string[];
  availableHoursPerDay: number;
  upcomingExams: { subject: string; date: string }[];
}): Promise<{
  weeklySchedule: { day: string; blocks: { timeSlot: string; subject: string; task: string; focusType: string }[] }[];
  recommendations: string[];
}> {
  const ai = getGenAI();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: `Create an optimized, realistic 7-day academic study plan for an engineering college student.
Context:
- Subjects: ${data.subjects.join(", ")}
- Weak subjects needing attention: ${data.weakSubjects.join(", ") || "None"}
- Pending Assignments: ${data.pendingAssignments.join(", ") || "None"}
- Daily study capacity: ${data.availableHoursPerDay} hours
- Upcoming Exams: ${JSON.stringify(data.upcomingExams)}

Return JSON matching:
{
  "weeklySchedule": [
    {
      "day": "Monday",
      "blocks": [
        { "timeSlot": "06:00 PM - 07:30 PM", "subject": "Subject Name", "task": "Task description", "focusType": "Deep Work / Problem Solving / Revision" }
      ]
    }
  ],
  "recommendations": ["Recommendation 1", "Recommendation 2"]
}`,
        config: {
          responseMimeType: "application/json",
        },
      });

      if (response.text) {
        return JSON.parse(response.text);
      }
    } catch (err) {
      console.warn("Gemini study plan fallback:", err);
    }
  }

  // Fallback plan
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const weeklySchedule = days.map((day, idx) => {
    const sub1 = data.weakSubjects[0] || data.subjects[idx % data.subjects.length] || "Core Subject";
    const sub2 = data.subjects[(idx + 1) % data.subjects.length] || "Secondary Subject";
    return {
      day,
      blocks: [
        {
          timeSlot: "05:30 PM - 07:00 PM",
          subject: sub1,
          task: idx % 2 === 0 ? "Theory revision and formula derivation" : "Lab assignment implementation & problem set",
          focusType: "Deep Work (High Urgency)",
        },
        {
          timeSlot: "07:30 PM - 09:00 PM",
          subject: sub2,
          task: "Review lecture slides and solve 5 practice questions",
          focusType: "Active Recall & Flashcards",
        },
      ],
    };
  });

  return {
    weeklySchedule,
    recommendations: [
      `Prioritize ${data.weakSubjects[0] || "weaker subjects"} using 50/10 Pomodoro intervals during peak focus periods.`,
      "Review upcoming assignment requirements at least 48 hours before the deadline to prevent last-minute cramming.",
      "Conduct a weekly 30-minute self-audit of your attendance percentage and productivity score.",
    ],
  };
}
