# Smart Student Companion 🎓

A modern, full-stack academic productivity and intelligence platform designed specifically for college and university students to eliminate fragmented tools and unify assignments, attendance prediction, marks analytics, smart notes with RAG, Pomodoro study sessions, and an AI Study Assistant into a single dashboard.

---

## 1. Problem Statement & Objectives

College students typically juggle 5–8 separate applications for:
- Assignment tracking
- Attendance calculations and shortage warnings
- Semester marks and GPA calculations
- Lecture notes and PDF uploads
- Pomodoro timers and study consistency
- Academic calendar deadlines
- Examination preparation and quiz generation

**Smart Student Companion** centralizes these workflows into an integrated SaaS application powered by:
1. **Concrete Data Structures & Algorithms (DSA)** for sorting, searching, prioritization, and dependency resolution.
2. **MongoDB / Document-Store Persistence** with strict user-level data isolation.
3. **AI-Powered Study Assistant** with RAG (Retrieval-Augmented Generation) based on cosine similarity.

---

## 2. Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS, Motion Animations, Lucide Icons.
- **Active Backend**: Node.js / Express TypeScript server on port 3000 running in sync with Vite.
- **Python FastAPI Reference Architecture**: Modular code under `server/app/` with Pydantic v2, Motor/PyMongo models, JWT auth, and Python DSA implementations.
- **Database**: Document-oriented schema with indexes for `users`, `assignments`, `attendance`, `marks`, `notes`, `study_goals`, `pomodoro_sessions`, `calendar_events`, `notifications`, and `activity_logs`.
- **AI Integration**: `@google/genai` using `gemini-3.8-flash` for explanations, note summarization, quiz generation, and weekly study plans.

---

## 3. Data Structures & Algorithms (DSA) Implementation

| Algorithm / Data Structure | Use Case in Platform | Best Case | Average Case | Worst Case | Space Complexity |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Merge Sort** | Stable sorting of assignments by due date / priority & calendar events | $O(n \log n)$ | $O(n \log n)$ | $O(n \log n)$ | $O(n)$ |
| **Quick Sort** | In-place partition sorting of marks and exam performance scores | $O(n \log n)$ | $O(n \log n)$ | $O(n^2)$ | $O(\log n)$ |
| **Binary Search** | Fast logarithmic search for sorted assignments & lecture notes by title | $O(1)$ | $O(\log n)$ | $O(\log n)$ | $O(1)$ |
| **Linear Search** | Substring and multi-tag filtering across unsorted note collections | $O(1)$ | $O(n)$ | $O(n)$ | $O(1)$ |
| **Binary Max-Heap** | Priority Queue computing most urgent assignments ($Score = Priority \times 100 + Proximity$) | $O(1)$ peek | $O(\log n)$ | $O(\log n)$ | $O(n)$ |
| **Hash Map / Dictionary** | $O(1)$ average lookup for subject-wise attendance and student records | $O(1)$ | $O(1)$ | $O(n)$ | $O(n)$ |
| **Kahn's BFS Graph Algorithm** | Topological sorting of prerequisite subject dependencies | $O(V + E)$ | $O(V + E)$ | $O(V + E)$ | $O(V)$ |
| **Cosine Similarity (RAG)** | Term-frequency vector similarity for smart note semantic context retrieval | $O(1)$ | $O(D \cdot W)$ | $O(D \cdot W)$ | $O(W)$ |
| **Stack** | Activity log history and undo operations for student actions | $O(1)$ | $O(1)$ | $O(1)$ | $O(n)$ |

---

## 4. Attendance Prediction Formula

The platform automatically computes:
$$\text{Attendance \%} = \left(\frac{A}{T}\right) \times 100$$
Where:
- $A$ = attended / present classes
- $T$ = total conducted classes

### Consecutive Classes Needed to Reach Target $P\%$ (e.g. 75%):
$$\text{classes\_needed} = \left\lceil \frac{P \cdot T - 100 \cdot A}{100 - P} \right\rceil$$

### Missable Classes While Staying $\ge P\%$:
$$\text{classes\_can\_miss} = \left\lfloor \frac{100 \cdot A - P \cdot T}{P} \right\rfloor$$

---

## 5. REST API Endpoints

- `POST /api/auth/register` - Create student account (bcrypt + JWT)
- `POST /api/auth/login` - Authenticate student
- `GET /api/auth/me` - Authenticated student profile
- `GET /api/assignments` - Query assignments with DSA search, sort & filters
- `POST /api/assignments` - Create assignment
- `GET /api/dsa/heap-urgent` - Max-Heap priority queue of urgent tasks
- `GET /api/attendance` - Subject attendance and $O(1)$ hash map lookup
- `POST /api/attendance` - Upsert attendance record (`user_id + subject`)
- `GET /api/attendance/prediction` - Predictive attendance recovery metrics
- `GET /api/marks/analytics` - Highest, lowest, average, and grade distribution
- `POST /api/notes/upload` - Multipart file upload (PDF, PNG, JPG)
- `POST /api/study/session` - Save Pomodoro study interval
- `GET /api/study/statistics` - Daily, weekly, monthly study hours
- `GET /api/analytics/productivity` - Comprehensive 0–100 productivity score
- `POST /api/ai/ask` - AI Academic Tutor topic explanation
- `POST /api/ai/summarize` - Note summarizer
- `POST /api/ai/quiz` - Dynamic MCQ and question generation
- `POST /api/ai/study-plan` - Adaptive 7-day study planner
- `POST /api/ai/rag-search` - Cosine similarity RAG note retrieval
- `GET /api/docs` - Interactive Swagger API documentation

---

## 6. How to Run

### Development:
\`\`\`bash
npm run dev
\`\`\`
Starts the Express full-stack server and Vite middleware on port 3000.

### Production Build:
\`\`\`bash
npm run build
npm start
\`\`\`
Runs the bundled production server from \`dist/server.cjs\`.
