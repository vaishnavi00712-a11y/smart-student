import express from "express";
import path from "path";
import fs from "fs";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import multer from "multer";
import { createServer as createViteServer } from "vite";
import {
  db,
  UserDocument,
  AssignmentDocument,
  AttendanceDocument,
  MarkDocument,
  NoteDocument,
  StudyGoalDocument,
  PomodoroSessionDocument,
  CalendarEventDocument,
  NotificationDocument,
} from "./server/db";
import {
  mergeSort,
  quickSort,
  binarySearch,
  linearSearch,
  PriorityQueue,
  computeAssignmentUrgency,
  calculateAttendancePrediction,
  PrerequisiteGraph,
  searchNotesRAG,
  calculateProductivityScore,
} from "./server/dsa";
import {
  askGeminiStudyAssistant,
  summarizeNotesWithGemini,
  generateQuizWithGemini,
  generateStudyPlanWithGemini,
} from "./server/gemini";

const JWT_SECRET = process.env.JWT_SECRET || "smart-student-companion-secret-key-2026";
const PORT = 3000;

// Setup upload directory
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `student-file-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 15 * 1024 * 1024 }, // 15MB limit
  fileFilter: (_req, file, cb) => {
    const allowed = [".pdf", ".png", ".jpg", ".jpeg", ".webp", ".txt", ".md"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error("Only PDF, PNG, JPG, JPEG, and text files are allowed."));
    }
  },
});

async function startServer() {
  const app = express();
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use("/uploads", express.static(UPLOADS_DIR));

  // ==========================================
  // JWT AUTH MIDDLEWARE
  // ==========================================
  const authenticate = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Authentication required. Bearer token missing." });
    }
    const token = authHeader.split(" ")[1];
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; email: string };
      const user = db.findOne("users", (u: UserDocument) => u.id === decoded.userId);
      if (!user) {
        return res.status(401).json({ error: "User session expired or not found." });
      }
      req.user = user;
      next();
    } catch {
      return res.status(401).json({ error: "Invalid or expired authorization token." });
    }
  };

  // ==========================================
  // 1. AUTHENTICATION ROUTES
  // ==========================================

  // POST /api/auth/register
  app.post("/api/auth/register", (req, res) => {
    const { name, email, password, course, year, college } = req.body;
    if (!name || !email || !password || !course) {
      return res.status(422).json({ error: "Missing required fields (name, email, password, course)." });
    }

    const existing = db.findOne("users", (u: UserDocument) => u.email.toLowerCase() === email.toLowerCase().trim());
    if (existing) {
      return res.status(400).json({ error: "An account with this email address already exists." });
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);
    const now = new Date().toISOString();

    const newUser: UserDocument = {
      id: `user-${Date.now()}`,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      passwordHash,
      course: course.trim(),
      year: year || "1st Year",
      college: college || "College of Engineering",
      createdAt: now,
      updatedAt: now,
    };

    db.insertOne("users", newUser);
    db.logActivity(newUser.id, "USER_REGISTERED", "User", "Account registered successfully");

    const token = jwt.sign({ userId: newUser.id, email: newUser.email }, JWT_SECRET, { expiresIn: "7d" });
    const { passwordHash: _, ...safeUser } = newUser;

    return res.status(201).json({
      message: "Registration successful",
      token,
      user: safeUser,
    });
  });

  // POST /api/auth/login
  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(422).json({ error: "Email and password are required." });
    }

    const user = db.findOne("users", (u: UserDocument) => u.email.toLowerCase() === email.toLowerCase().trim());
    if (!user) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const isValid = bcrypt.compareSync(password, user.passwordHash);
    if (!isValid) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
    const { passwordHash: _, ...safeUser } = user;

    db.logActivity(user.id, "USER_LOGIN", "User", "Signed in to platform");

    return res.json({
      message: "Login successful",
      token,
      user: safeUser,
    });
  });

  // GET /api/auth/me
  app.get("/api/auth/me", authenticate, (req: any, res) => {
    const { passwordHash: _, ...safeUser } = req.user;
    return res.json({ user: safeUser });
  });

  // PUT /api/auth/profile
  app.put("/api/auth/profile", authenticate, (req: any, res) => {
    const { name, email, course, year, college, avatarUrl } = req.body;

    if (email !== undefined) {
      const normalizedEmail = String(email).toLowerCase().trim();
      if (!normalizedEmail) {
        return res.status(400).json({ error: "Email cannot be empty." });
      }
      const emailTaken = db.findOne(
        "users",
        (u: UserDocument) => u.email.toLowerCase() === normalizedEmail && u.id !== req.user.id
      );
      if (emailTaken) {
        return res.status(400).json({ error: "An account with this email address already exists." });
      }
    }

    const updated = db.updateOne(
      "users",
      (u: UserDocument) => u.id === req.user.id,
      {
        name,
        course,
        year,
        college,
        avatarUrl,
        ...(email !== undefined ? { email: String(email).toLowerCase().trim() } : {}),
      }
    );
    const { passwordHash: _, ...safeUser } = updated;
    return res.json({ message: "Profile updated successfully", user: safeUser });
  });

  // POST /api/auth/change-password
  app.post("/api/auth/change-password", authenticate, (req: any, res) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(422).json({ error: "Current and new password are required." });
    }

    const isValid = bcrypt.compareSync(currentPassword, req.user.passwordHash);
    if (!isValid) {
      return res.status(400).json({ error: "Current password does not match." });
    }

    const salt = bcrypt.genSaltSync(10);
    const newHash = bcrypt.hashSync(newPassword, salt);
    db.updateOne("users", (u: UserDocument) => u.id === req.user.id, { passwordHash: newHash });

    return res.json({ message: "Password updated successfully" });
  });

  // ==========================================
  // 2. ASSIGNMENTS (WITH MERGE SORT, QUICK SORT, BINARY SEARCH, HEAP)
  // ==========================================

  // GET /api/assignments
  app.get("/api/assignments", authenticate, (req: any, res) => {
    const userId = req.user.id;
    let assignments = db.find("assignments", (a: AssignmentDocument) => a.userId === userId);

    const { status, priority, subject, sortBy, search, useAlgorithm } = req.query as Record<string, string>;

    // Filtering
    if (status && status !== "All") {
      assignments = assignments.filter((a) => a.status === status);
    }
    if (priority && priority !== "All") {
      assignments = assignments.filter((a) => a.priority === priority);
    }
    if (subject && subject !== "All") {
      assignments = assignments.filter((a) => a.subject.toLowerCase() === subject.toLowerCase());
    }

    let searchMetrics: any = null;
    // Searching: If search is specified, compare Linear vs Binary Search
    if (search && search.trim()) {
      const q = search.trim();
      if (useAlgorithm === "binary") {
        // Binary search requires pre-sorted by title
        const titleSorted = [...assignments].sort((a, b) => a.title.localeCompare(b.title));
        const bResult = binarySearch(titleSorted, q, (item) => item.title);
        searchMetrics = bResult.metrics;
        assignments = bResult.item ? [bResult.item] : [];
      } else {
        const lResult = linearSearch(assignments, (item) =>
          item.title.toLowerCase().includes(q.toLowerCase()) ||
          item.description.toLowerCase().includes(q.toLowerCase())
        );
        searchMetrics = lResult.metrics;
        assignments = lResult.results;
      }
    }

    // Sorting with DSA Merge Sort or Quick Sort
    let sortMetrics: any = null;
    if (sortBy === "priority") {
      const priorityOrder: Record<string, number> = { High: 3, Medium: 2, Low: 1 };
      const resSort = mergeSort(assignments, (a, b) => (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0));
      assignments = resSort.sorted;
      sortMetrics = resSort.metrics;
    } else if (sortBy === "dueDate" || !sortBy) {
      const resSort = mergeSort(assignments, (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
      assignments = resSort.sorted;
      sortMetrics = resSort.metrics;
    } else if (sortBy === "title") {
      const resSort = quickSort(assignments, (a, b) => a.title.localeCompare(b.title));
      assignments = resSort.sorted;
      sortMetrics = resSort.metrics;
    }

    return res.json({
      assignments,
      total: assignments.length,
      dsaMetrics: {
        sorting: sortMetrics,
        searching: searchMetrics,
      },
    });
  });

  // GET /api/assignments/:id
  app.get("/api/assignments/:id", authenticate, (req: any, res) => {
    const assignment = db.findOne("assignments", (a: AssignmentDocument) => a.id === req.params.id && a.userId === req.user.id);
    if (!assignment) return res.status(404).json({ error: "Assignment not found." });
    return res.json({ assignment });
  });

  // POST /api/assignments
  app.post("/api/assignments", authenticate, (req: any, res) => {
    const { title, description, subject, priority, status, dueDate } = req.body;
    if (!title || !subject || !dueDate) {
      return res.status(422).json({ error: "Title, subject, and dueDate are required." });
    }

    const now = new Date().toISOString();
    const newAssignment: AssignmentDocument = {
      id: `assign-${Date.now()}`,
      userId: req.user.id,
      title: title.trim(),
      description: description || "",
      subject: subject.trim(),
      priority: priority || "Medium",
      status: status || "Pending",
      dueDate,
      createdAt: now,
      updatedAt: now,
    };

    db.insertOne("assignments", newAssignment);
    db.logActivity(req.user.id, "ASSIGNMENT_CREATED", "Assignment", `Added assignment: ${newAssignment.title}`);

    return res.status(201).json({ assignment: newAssignment, message: "Assignment created successfully." });
  });

  // PUT /api/assignments/:id
  app.put("/api/assignments/:id", authenticate, (req: any, res) => {
    const existing = db.findOne("assignments", (a: AssignmentDocument) => a.id === req.params.id && a.userId === req.user.id);
    if (!existing) return res.status(404).json({ error: "Assignment not found." });

    const updated = db.updateOne(
      "assignments",
      (a: AssignmentDocument) => a.id === req.params.id,
      { ...req.body, updatedAt: new Date().toISOString() }
    );

    db.logActivity(req.user.id, "ASSIGNMENT_UPDATED", "Assignment", `Updated assignment: ${updated.title}`);
    return res.json({ assignment: updated, message: "Assignment updated successfully." });
  });

  // PATCH /api/assignments/:id/status
  app.patch("/api/assignments/:id/status", authenticate, (req: any, res) => {
    const { status } = req.body;
    const existing = db.findOne("assignments", (a: AssignmentDocument) => a.id === req.params.id && a.userId === req.user.id);
    if (!existing) return res.status(404).json({ error: "Assignment not found." });

    const updated = db.updateOne("assignments", (a: AssignmentDocument) => a.id === req.params.id, { status });
    db.logActivity(req.user.id, "ASSIGNMENT_STATUS_CHANGE", "Assignment", `Marked ${updated.title} as ${status}`);
    return res.json({ assignment: updated });
  });

  // DELETE /api/assignments/:id
  app.delete("/api/assignments/:id", authenticate, (req: any, res) => {
    const success = db.deleteOne("assignments", (a: AssignmentDocument) => a.id === req.params.id && a.userId === req.user.id);
    if (!success) return res.status(404).json({ error: "Assignment not found." });
    return res.json({ message: "Assignment deleted successfully." });
  });

  // GET /api/dsa/heap-urgent (Priority Queue Heap of Urgent Tasks)
  app.get("/api/dsa/heap-urgent", authenticate, (req: any, res) => {
    const assignments = db.find("assignments", (a: AssignmentDocument) => a.userId === req.user.id && a.status !== "Completed");
    const pq = new PriorityQueue<AssignmentDocument>();

    for (const a of assignments) {
      const urgency = computeAssignmentUrgency(a.dueDate, a.priority, a.status);
      pq.insert(a, urgency);
    }

    const prioritized = pq.toSortedArray();
    return res.json({
      urgentAssignments: prioritized,
      heapMetrics: {
        algorithm: "Binary Max-Heap (Priority Queue)",
        insertComplexity: "O(log n)",
        extractMaxComplexity: "O(log n)",
        spaceComplexity: "O(n)",
        totalItemsInHeap: assignments.length,
      },
    });
  });

  // ==========================================
  // 3. ATTENDANCE & PREDICTION ALGORITHM
  // ==========================================

  // GET /api/attendance
  app.get("/api/attendance", authenticate, (req: any, res) => {
    const records = db.find("attendance", (a: AttendanceDocument) => a.userId === req.user.id);

    // Hash Map / Dictionary Concept: O(1) lookup map
    const subjectMap: Record<string, AttendanceDocument> = {};
    for (const r of records) {
      subjectMap[r.subject] = r;
    }

    const detailed = records.map((r) => {
      const prediction = calculateAttendancePrediction(r.present, r.total, 75);
      return {
        ...r,
        percentage: prediction.currentPercentage,
        status: prediction.status,
        classesNeededTo75: prediction.classesNeeded,
        classesCanMiss: prediction.classesCanMiss,
      };
    });

    const totalPresent = records.reduce((acc, curr) => acc + curr.present, 0);
    const totalClasses = records.reduce((acc, curr) => acc + curr.total, 0);
    const overallPercentage = totalClasses > 0 ? Number(((totalPresent / totalClasses) * 100).toFixed(2)) : 100;

    return res.json({
      attendance: detailed,
      summary: {
        overallPercentage,
        totalSubjects: records.length,
        safeCount: detailed.filter((d) => d.status === "Safe").length,
        shortageCount: detailed.filter((d) => d.status === "Shortage").length,
        warningCount: detailed.filter((d) => d.status === "Warning").length,
      },
      lookupComplexity: {
        dataStructure: "Hash Map / Dictionary",
        averageLookup: "O(1)",
        worstCaseLookup: "O(n)",
        purpose: "Instant O(1) retrieval of subject attendance state",
      },
    });
  });

  // POST /api/attendance (UPSERT operation)
  app.post("/api/attendance", authenticate, (req: any, res) => {
    const { subject, present, total } = req.body;
    if (!subject || present === undefined || total === undefined) {
      return res.status(422).json({ error: "Subject, present classes, and total classes are required." });
    }

    const p = parseInt(present, 10);
    const t = parseInt(total, 10);
    if (p > t) {
      return res.status(400).json({ error: "Present classes cannot exceed total classes." });
    }

    const result = db.upsertAttendance(req.user.id, subject.trim(), p, t);
    db.logActivity(req.user.id, "ATTENDANCE_UPSERTED", "Attendance", `Updated attendance for ${subject}: ${p}/${t}`);

    const prediction = calculateAttendancePrediction(p, t, 75);
    return res.status(200).json({
      attendance: {
        ...result,
        percentage: prediction.currentPercentage,
        status: prediction.status,
        classesNeededTo75: prediction.classesNeeded,
        classesCanMiss: prediction.classesCanMiss,
      },
      message: "Attendance recorded successfully (Upsert completed).",
    });
  });

  // DELETE /api/attendance/:id
  app.delete("/api/attendance/:id", authenticate, (req: any, res) => {
    const success = db.deleteOne("attendance", (a: AttendanceDocument) => a.id === req.params.id && a.userId === req.user.id);
    if (!success) return res.status(404).json({ error: "Record not found." });
    return res.json({ message: "Attendance record deleted." });
  });

  // GET /api/attendance/prediction
  app.get("/api/attendance/prediction", authenticate, (req: any, res) => {
    const records = db.find("attendance", (a: AttendanceDocument) => a.userId === req.user.id);
    const target = parseFloat(req.query.target as string) || 75;

    const predictions = records.map((r) => {
      const pred = calculateAttendancePrediction(r.present, r.total, target);
      return {
        subject: r.subject,
        present: r.present,
        total: r.total,
        currentPercentage: pred.currentPercentage,
        targetPercentage: target,
        classesNeeded: pred.classesNeeded,
        classesCanMiss: pred.classesCanMiss,
        status: pred.status,
      };
    });

    return res.json({
      predictions,
      formula: "classes_needed = ceil((P * T - 100 * A) / (100 - P))",
      complexity: "O(1) calculation per subject, O(N) aggregate over N subjects",
    });
  });

  // ==========================================
  // 4. MARKS ANALYZER (DSA ARRAYS & STATS)
  // ==========================================

  // GET /api/marks
  app.get("/api/marks", authenticate, (req: any, res) => {
    const marks = db.find("marks", (m: MarkDocument) => m.userId === req.user.id);
    return res.json({ marks });
  });

  // POST /api/marks
  app.post("/api/marks", authenticate, (req: any, res) => {
    const { subject, internalMarks, externalMarks, maxMarks, examType } = req.body;
    if (!subject || maxMarks === undefined) {
      return res.status(422).json({ error: "Subject and maxMarks are required." });
    }

    const internal = parseFloat(internalMarks) || 0;
    const external = parseFloat(externalMarks) || 0;
    const max = parseFloat(maxMarks);
    const total = internal + external;
    const percentage = Number(((total / max) * 100).toFixed(2));

    let grade = "F";
    if (percentage >= 90) grade = "A+";
    else if (percentage >= 80) grade = "A";
    else if (percentage >= 70) grade = "B+";
    else if (percentage >= 60) grade = "B";
    else if (percentage >= 50) grade = "C";
    else if (percentage >= 40) grade = "D";

    const newMark: MarkDocument = {
      id: `mark-${Date.now()}`,
      userId: req.user.id,
      subject: subject.trim(),
      internalMarks: internal,
      externalMarks: external,
      maxMarks: max,
      totalMarks: total,
      percentage,
      grade,
      examType: examType || "Semester Examination",
      updatedAt: new Date().toISOString(),
    };

    db.insertOne("marks", newMark);
    db.logActivity(req.user.id, "MARKS_RECORDED", "Marks", `Recorded marks for ${newMark.subject}: ${total}/${max} (${grade})`);

    return res.status(201).json({ mark: newMark, message: "Mark recorded successfully." });
  });

  // DELETE /api/marks/:id
  app.delete("/api/marks/:id", authenticate, (req: any, res) => {
    const success = db.deleteOne("marks", (m: MarkDocument) => m.id === req.params.id && m.userId === req.user.id);
    if (!success) return res.status(404).json({ error: "Mark entry not found." });
    return res.json({ message: "Mark entry deleted." });
  });

  // GET /api/marks/analytics (DSA Sorting & Extremes)
  app.get("/api/marks/analytics", authenticate, (req: any, res) => {
    const marks = db.find("marks", (m: MarkDocument) => m.userId === req.user.id);
    if (marks.length === 0) {
      return res.json({
        totalSubjects: 0,
        averagePercentage: 0,
        highest: null,
        lowest: null,
        gradeDistribution: {},
        sortedMarks: [],
      });
    }

    // Quick sort subjects by percentage descending
    const qSorted = quickSort(marks, (a, b) => b.percentage - a.percentage);

    const highest = qSorted.sorted[0];
    const lowest = qSorted.sorted[qSorted.sorted.length - 1];
    const sum = marks.reduce((acc, curr) => acc + curr.percentage, 0);
    const averagePercentage = Number((sum / marks.length).toFixed(2));

    const gradeDistribution: Record<string, number> = { "A+": 0, A: 0, "B+": 0, B: 0, C: 0, D: 0, F: 0 };
    for (const m of marks) {
      gradeDistribution[m.grade] = (gradeDistribution[m.grade] || 0) + 1;
    }

    return res.json({
      totalSubjects: marks.length,
      averagePercentage,
      highest,
      lowest,
      gradeDistribution,
      sortedMarks: qSorted.sorted,
      dsaMetrics: qSorted.metrics,
    });
  });

  // ==========================================
  // 5. SMART NOTES & FILE UPLOAD
  // ==========================================

  // GET /api/notes
  app.get("/api/notes", authenticate, (req: any, res) => {
    let notes = db.find("notes", (n: NoteDocument) => n.userId === req.user.id);
    const { search, subject, tag } = req.query as Record<string, string>;

    if (subject && subject !== "All") {
      notes = notes.filter((n) => n.subject.toLowerCase() === subject.toLowerCase());
    }
    if (tag) {
      notes = notes.filter((n) => n.tags.some((t) => t.toLowerCase().includes(tag.toLowerCase())));
    }
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      notes = notes.filter(
        (n) =>
          n.title.toLowerCase().includes(q) ||
          n.content.toLowerCase().includes(q) ||
          n.subject.toLowerCase().includes(q) ||
          n.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    return res.json({ notes });
  });

  // POST /api/notes
  app.post("/api/notes", authenticate, (req: any, res) => {
    const { title, content, subject, folder, tags, fileUrl, fileName } = req.body;
    if (!title || !content || !subject) {
      return res.status(422).json({ error: "Title, content, and subject are required." });
    }

    const now = new Date().toISOString();
    const newNote: NoteDocument = {
      id: `note-${Date.now()}`,
      userId: req.user.id,
      title: title.trim(),
      content: content.trim(),
      subject: subject.trim(),
      folder: folder || "General",
      tags: Array.isArray(tags) ? tags : typeof tags === "string" ? tags.split(",").map((t: string) => t.trim()) : [],
      fileUrl,
      fileName,
      createdAt: now,
      updatedAt: now,
    };

    db.insertOne("notes", newNote);
    db.logActivity(req.user.id, "NOTE_CREATED", "Notes", `Created note: ${newNote.title}`);
    return res.status(201).json({ note: newNote, message: "Note created successfully." });
  });

  // PUT /api/notes/:id
  app.put("/api/notes/:id", authenticate, (req: any, res) => {
    const existing = db.findOne("notes", (n: NoteDocument) => n.id === req.params.id && n.userId === req.user.id);
    if (!existing) return res.status(404).json({ error: "Note not found." });

    const updated = db.updateOne("notes", (n: NoteDocument) => n.id === req.params.id, {
      ...req.body,
      updatedAt: new Date().toISOString(),
    });

    db.logActivity(req.user.id, "NOTE_UPDATED", "Notes", `Edited note: ${updated.title}`);
    return res.json({ note: updated, message: "Note updated." });
  });

  // DELETE /api/notes/:id
  app.delete("/api/notes/:id", authenticate, (req: any, res) => {
    const success = db.deleteOne("notes", (n: NoteDocument) => n.id === req.params.id && n.userId === req.user.id);
    if (!success) return res.status(404).json({ error: "Note not found." });
    return res.json({ message: "Note deleted." });
  });

  // POST /api/notes/upload (FastAPI/Express file upload)
  app.post("/api/notes/upload", authenticate, upload.single("file"), (req: any, res) => {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded or file rejected by validator." });
    }

    const fileUrl = `/uploads/${req.file.filename}`;
    return res.json({
      fileUrl,
      fileName: req.file.originalname,
      size: req.file.size,
      mimeType: req.file.mimetype,
      message: "File uploaded successfully.",
    });
  });

  // ==========================================
  // 6. POMODORO STUDY TIMER & SESSIONS
  // ==========================================

  // POST /api/study/session
  app.post("/api/study/session", authenticate, (req: any, res) => {
    const { subject, durationMinutes, notes, completed } = req.body;
    if (!subject || !durationMinutes) {
      return res.status(422).json({ error: "Subject and durationMinutes are required." });
    }

    const now = new Date();
    const startTime = new Date(now.getTime() - durationMinutes * 60 * 1000).toISOString();
    const endTime = now.toISOString();

    const session: PomodoroSessionDocument = {
      id: `pom-${Date.now()}`,
      userId: req.user.id,
      subject: subject.trim(),
      durationMinutes: parseInt(durationMinutes, 10),
      startTime,
      endTime,
      completed: completed !== undefined ? completed : true,
      notes: notes || "",
    };

    db.insertOne("pomodoro_sessions", session);
    db.logActivity(req.user.id, "POMODORO_COMPLETED", "Pomodoro", `Focused on ${subject} for ${durationMinutes} minutes`);

    return res.status(201).json({ session, message: "Study session recorded." });
  });

  // GET /api/study/statistics
  app.get("/api/study/statistics", authenticate, (req: any, res) => {
    const sessions = db.find("pomodoro_sessions", (s: PomodoroSessionDocument) => s.userId === req.user.id);

    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    let dailyMinutes = 0;
    let weeklyMinutes = 0;
    let monthlyMinutes = 0;

    const subjectBreakdown: Record<string, number> = {};

    for (const s of sessions) {
      const sessionDate = new Date(s.endTime);
      if (sessionDate >= oneDayAgo) dailyMinutes += s.durationMinutes;
      if (sessionDate >= sevenDaysAgo) weeklyMinutes += s.durationMinutes;
      if (sessionDate >= thirtyDaysAgo) monthlyMinutes += s.durationMinutes;

      subjectBreakdown[s.subject] = (subjectBreakdown[s.subject] || 0) + s.durationMinutes;
    }

    return res.json({
      totalSessions: sessions.length,
      dailyStudyHours: Number((dailyMinutes / 60).toFixed(1)),
      weeklyStudyHours: Number((weeklyMinutes / 60).toFixed(1)),
      monthlyStudyHours: Number((monthlyMinutes / 60).toFixed(1)),
      subjectBreakdown,
      recentSessions: sessions.slice(-10).reverse(),
    });
  });

  // ==========================================
  // 7. STUDY GOALS
  // ==========================================

  // GET /api/goals
  app.get("/api/goals", authenticate, (req: any, res) => {
    const goals = db.find("study_goals", (g: StudyGoalDocument) => g.userId === req.user.id);
    const enriched = goals.map((g) => ({
      ...g,
      progressPercentage: Math.min(100, Number(((g.completedHours / g.targetHours) * 100).toFixed(1))),
    }));
    return res.json({ goals: enriched });
  });

  // POST /api/goals
  app.post("/api/goals", authenticate, (req: any, res) => {
    const { title, subject, targetHours, deadline } = req.body;
    if (!title || !subject || !targetHours || !deadline) {
      return res.status(422).json({ error: "Title, subject, targetHours, and deadline are required." });
    }

    const newGoal: StudyGoalDocument = {
      id: `goal-${Date.now()}`,
      userId: req.user.id,
      title: title.trim(),
      subject: subject.trim(),
      targetHours: parseFloat(targetHours),
      completedHours: 0,
      deadline,
      status: "active",
      createdAt: new Date().toISOString(),
    };

    db.insertOne("study_goals", newGoal);
    db.logActivity(req.user.id, "GOAL_CREATED", "Goal", `New goal created: ${newGoal.title}`);
    return res.status(201).json({ goal: newGoal, message: "Goal created successfully." });
  });

  // PUT /api/goals/:id
  app.put("/api/goals/:id", authenticate, (req: any, res) => {
    const existing = db.findOne("study_goals", (g: StudyGoalDocument) => g.id === req.params.id && g.userId === req.user.id);
    if (!existing) return res.status(404).json({ error: "Goal not found." });

    const updated = db.updateOne("study_goals", (g: StudyGoalDocument) => g.id === req.params.id, req.body);
    return res.json({ goal: updated, message: "Goal updated." });
  });

  // DELETE /api/goals/:id
  app.delete("/api/goals/:id", authenticate, (req: any, res) => {
    const success = db.deleteOne("study_goals", (g: StudyGoalDocument) => g.id === req.params.id && g.userId === req.user.id);
    if (!success) return res.status(404).json({ error: "Goal not found." });
    return res.json({ message: "Goal deleted." });
  });

  // ==========================================
  // 8. CALENDAR & NOTIFICATIONS
  // ==========================================

  // GET /api/calendar
  app.get("/api/calendar", authenticate, (req: any, res) => {
    const events = db.find("calendar_events", (e: CalendarEventDocument) => e.userId === req.user.id);
    // Chronological Merge Sort
    const sorted = mergeSort(events, (a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
    return res.json({ events: sorted.sorted });
  });

  // POST /api/calendar
  app.post("/api/calendar", authenticate, (req: any, res) => {
    const { title, eventType, startDate, endDate, location, notes } = req.body;
    if (!title || !eventType || !startDate) {
      return res.status(422).json({ error: "Title, eventType, and startDate are required." });
    }

    const newEvent: CalendarEventDocument = {
      id: `cal-${Date.now()}`,
      userId: req.user.id,
      title: title.trim(),
      eventType,
      startDate,
      endDate,
      location,
      notes,
    };

    db.insertOne("calendar_events", newEvent);
    db.logActivity(req.user.id, "EVENT_CREATED", "Calendar", `Created event: ${newEvent.title}`);
    return res.status(201).json({ event: newEvent, message: "Calendar event scheduled." });
  });

  // DELETE /api/calendar/:id
  app.delete("/api/calendar/:id", authenticate, (req: any, res) => {
    const success = db.deleteOne("calendar_events", (e: CalendarEventDocument) => e.id === req.params.id && e.userId === req.user.id);
    if (!success) return res.status(404).json({ error: "Event not found." });
    return res.json({ message: "Event removed." });
  });

  // GET /api/notifications
  app.get("/api/notifications", authenticate, (req: any, res) => {
    const notifs = db.find("notifications", (n: NotificationDocument) => n.userId === req.user.id);
    notifs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const unreadCount = notifs.filter((n) => !n.read).length;
    return res.json({ notifications: notifs, unreadCount });
  });

  // PATCH /api/notifications/:id/read
  app.patch("/api/notifications/:id/read", authenticate, (req: any, res) => {
    const updated = db.updateOne("notifications", (n: NotificationDocument) => n.id === req.params.id && n.userId === req.user.id, { read: true });
    return res.json({ notification: updated });
  });

  // ==========================================
  // 9. PRODUCTIVITY SCORE & RECENT ACTIVITY
  // ==========================================

  app.get("/api/analytics/productivity", authenticate, (req: any, res) => {
    const userId = req.user.id;
    const assignments = db.find("assignments", (a: AssignmentDocument) => a.userId === userId);
    const completedAssignments = assignments.filter((a) => a.status === "Completed").length;

    const attendanceRecords = db.find("attendance", (a: AttendanceDocument) => a.userId === userId);
    const totalP = attendanceRecords.reduce((acc, curr) => acc + curr.present, 0);
    const totalC = attendanceRecords.reduce((acc, curr) => acc + curr.total, 0);
    const attendanceAvg = totalC > 0 ? (totalP / totalC) * 100 : 100;

    const pomodoroSessions = db.find("pomodoro_sessions", (s: PomodoroSessionDocument) => s.userId === userId);
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weekMinutes = pomodoroSessions
      .filter((s) => new Date(s.endTime) >= sevenDaysAgo)
      .reduce((acc, curr) => acc + curr.durationMinutes, 0);
    const studyHoursThisWeek = Number((weekMinutes / 60).toFixed(1));

    const goals = db.find("study_goals", (g: StudyGoalDocument) => g.userId === userId);
    const completedGoals = goals.filter((g) => g.status === "completed" || g.completedHours >= g.targetHours).length;
    const targetStudyHours = goals.reduce((acc, curr) => acc + curr.targetHours, 0) || 15;

    const prodResult = calculateProductivityScore({
      completedAssignments,
      totalAssignments: assignments.length,
      attendanceAvg,
      studyHoursThisWeek,
      targetStudyHours,
      completedGoals,
      totalGoals: goals.length,
      pomodoroSessionsCount: pomodoroSessions.length,
    });

    const recentActivities = db
      .find("activity_logs", (l: any) => l.userId === userId)
      .slice(-10)
      .reverse();

    return res.json({
      productivityScore: prodResult.score,
      factors: prodResult.factors,
      metrics: {
        completedAssignments,
        totalAssignments: assignments.length,
        attendanceAvg: Number(attendanceAvg.toFixed(1)),
        studyHoursThisWeek,
        targetStudyHours,
        completedGoals,
        pomodoroSessionsCount: pomodoroSessions.length,
      },
      recentActivities,
    });
  });

  // ==========================================
  // 10. GRAPH ALGORITHM (PREREQUISITE TREE)
  // ==========================================

  app.get("/api/dsa/prerequisites-graph", authenticate, (_req, res) => {
    const graph = new PrerequisiteGraph();
    // Default academic computer science prerequisite graph
    graph.addPrerequisite("Data Structures", "Programming Fundamentals");
    graph.addPrerequisite("Design & Analysis of Algorithms", "Data Structures");
    graph.addPrerequisite("Design & Analysis of Algorithms", "Discrete Mathematics");
    graph.addPrerequisite("Database Management Systems", "Data Structures");
    graph.addPrerequisite("Operating Systems", "Computer Architecture");
    graph.addPrerequisite("Operating Systems", "Data Structures");
    graph.addPrerequisite("Computer Networks", "Operating Systems");
    graph.addPrerequisite("Machine Learning & AI", "Design & Analysis of Algorithms");
    graph.addPrerequisite("Machine Learning & AI", "Probability & Statistics");

    const orderResult = graph.getRecommendedStudyOrder();
    return res.json({
      topologicalOrder: orderResult.order,
      hasCycle: orderResult.hasCycle,
      complexity: {
        algorithm: "Topological Sort via Kahn's BFS Algorithm",
        timeComplexity: "O(V + E) where V = Subjects, E = Prerequisite dependencies",
        spaceComplexity: "O(V) for in-degree map and queue",
      },
      edges: [
        { from: "Programming Fundamentals", to: "Data Structures" },
        { from: "Data Structures", to: "Design & Analysis of Algorithms" },
        { from: "Discrete Mathematics", to: "Design & Analysis of Algorithms" },
        { from: "Data Structures", to: "Database Management Systems" },
        { from: "Computer Architecture", to: "Operating Systems" },
        { from: "Data Structures", to: "Operating Systems" },
        { from: "Operating Systems", to: "Computer Networks" },
        { from: "Design & Analysis of Algorithms", to: "Machine Learning & AI" },
        { from: "Probability & Statistics", to: "Machine Learning & AI" },
      ],
    });
  });

  // ==========================================
  // 11. AI STUDY ASSISTANT & RAG ENDPOINTS
  // ==========================================

  // POST /api/ai/ask
  app.post("/api/ai/ask", authenticate, async (req: any, res) => {
    const { prompt, context } = req.body;
    if (!prompt) return res.status(422).json({ error: "Prompt is required." });

    const answer = await askGeminiStudyAssistant(prompt, context);
    return res.json({ answer });
  });

  // POST /api/ai/summarize
  app.post("/api/ai/summarize", authenticate, async (req: any, res) => {
    const { title, content } = req.body;
    if (!content) return res.status(422).json({ error: "Content is required for summarization." });

    const summary = await summarizeNotesWithGemini(title || "Study Note", content);
    return res.json({ summary });
  });

  // POST /api/ai/quiz
  app.post("/api/ai/quiz", authenticate, async (req: any, res) => {
    const { topicOrContent } = req.body;
    if (!topicOrContent) return res.status(422).json({ error: "Topic or content is required." });

    const quiz = await generateQuizWithGemini(topicOrContent);
    return res.json({ quiz });
  });

  // POST /api/ai/study-plan
  app.post("/api/ai/study-plan", authenticate, async (req: any, res) => {
    const userId = req.user.id;
    const assignments = db.find("assignments", (a: AssignmentDocument) => a.userId === userId && a.status !== "Completed");
    const attendance = db.find("attendance", (a: AttendanceDocument) => a.userId === userId);
    const marks = db.find("marks", (m: MarkDocument) => m.userId === userId);
    const calendar = db.find("calendar_events", (e: CalendarEventDocument) => e.userId === userId && e.eventType === "Exam");

    const subjects = Array.from(new Set([
      ...assignments.map((a) => a.subject),
      ...attendance.map((a) => a.subject),
      ...marks.map((m) => m.subject),
    ]));

    // Detect weak subjects from low marks or attendance shortage
    const weakSubjects = marks.filter((m) => m.percentage < 75).map((m) => m.subject);

    const plan = await generateStudyPlanWithGemini({
      subjects: subjects.length > 0 ? subjects : ["Database Systems", "Operating Systems", "Algorithms"],
      weakSubjects,
      pendingAssignments: assignments.map((a) => `${a.title} (${a.subject})`),
      availableHoursPerDay: req.body.availableHoursPerDay || 3,
      upcomingExams: calendar.map((e) => ({ subject: e.title, date: e.startDate })),
    });

    return res.json({ plan });
  });

  // POST /api/ai/rag-search (Cosine Similarity Note Retrieval)
  app.post("/api/ai/rag-search", authenticate, async (req: any, res) => {
    const { query } = req.body;
    if (!query) return res.status(422).json({ error: "Query string is required." });

    const notes = db.find("notes", (n: NoteDocument) => n.userId === req.user.id);
    const topChunks = searchNotesRAG(notes, query, 3);

    const retrievedContext = topChunks
      .map((c) => `[Source Note: "${c.note.title}" (Subject: ${c.note.subject}, Cosine Similarity: ${c.similarity.toFixed(3)})]\n${c.note.content}`)
      .join("\n\n---\n\n");

    const answer = await askGeminiStudyAssistant(query, retrievedContext);

    return res.json({
      answer,
      retrievedChunks: topChunks.map((c) => ({
        id: c.note.id,
        title: c.note.title,
        subject: c.note.subject,
        similarity: Number(c.similarity.toFixed(4)),
      })),
      algorithmMetrics: {
        technique: "Vector Embedding / Term-Frequency Cosine Similarity RAG",
        formula: "cos(θ) = (A · B) / (||A|| * ||B||)",
        topK: topChunks.length,
        totalNotesScanned: notes.length,
      },
    });
  });

  // ==========================================
  // 12. FLASHCARDS
  // ==========================================

  app.get("/api/flashcards", authenticate, (req: any, res) => {
    const flashcards = db.find("flashcards", (f: any) => f.userId === req.user.id);
    return res.json({ flashcards });
  });

  app.post("/api/flashcards", authenticate, (req: any, res) => {
    const { subject, question, answer, difficulty } = req.body;
    if (!question || !answer || !subject) {
      return res.status(422).json({ error: "Subject, question, and answer are required." });
    }

    const card = db.insertOne("flashcards", {
      userId: req.user.id,
      subject,
      question,
      answer,
      difficulty: difficulty || "Medium",
      reviewedCount: 0,
      lastReviewed: new Date().toISOString(),
    });

    return res.status(201).json({ flashcard: card });
  });

  // ==========================================
  // 13. INTERACTIVE SWAGGER / API DOCS
  // ==========================================

  app.get("/api/docs", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>Smart Student Companion - REST API Documentation</title>
  <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css">
  <style>
    body { margin: 0; background: #fafafa; font-family: sans-serif; }
    .topbar { background: #0f172a; color: white; padding: 14px 24px; display: flex; align-items: center; justify-content: space-between; }
    .topbar h1 { margin: 0; font-size: 18px; font-weight: 600; }
    .topbar a { color: #38bdf8; text-decoration: none; font-size: 14px; }
  </style>
</head>
<body>
  <div class="topbar">
    <h1>Smart Student Companion - Swagger REST API Specs</h1>
    <a href="/">← Return to App Dashboard</a>
  </div>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    SwaggerUIBundle({
      url: '/api/openapi.json',
      dom_id: '#swagger-ui',
      presets: [SwaggerUIBundle.presets.apis],
      layout: "BaseLayout"
    });
  </script>
</body>
</html>
    `);
  });

  app.get("/api/openapi.json", (_req, res) => {
    res.json({
      openapi: "3.0.0",
      info: {
        title: "Smart Student Companion REST APIs",
        version: "1.0.0",
        description: "Complete REST API endpoints for assignments, attendance prediction, marks analytics, DSA algorithms, smart notes RAG, and AI study assistant.",
      },
      components: {
        securitySchemes: {
          BearerAuth: {
            type: "http",
            scheme: "bearer",
            bearerFormat: "JWT",
          },
        },
      },
      security: [{ BearerAuth: [] }],
      paths: {
        "/api/auth/register": { post: { summary: "Register new student account" } },
        "/api/auth/login": { post: { summary: "Login and obtain JWT token" } },
        "/api/auth/me": { get: { summary: "Get current authenticated student profile" } },
        "/api/assignments": {
          get: { summary: "List assignments with Merge/Quick Sort, Binary/Linear Search and status filters" },
          post: { summary: "Create new assignment" },
        },
        "/api/assignments/{id}": {
          get: { summary: "Get assignment by ID" },
          put: { summary: "Update assignment" },
          delete: { summary: "Delete assignment" },
        },
        "/api/dsa/heap-urgent": { get: { summary: "Max-Heap Priority Queue urgent assignments" } },
        "/api/attendance": {
          get: { summary: "Subject-wise attendance list and O(1) hash map" },
          post: { summary: "Upsert attendance record (user_id + subject)" },
        },
        "/api/attendance/prediction": { get: { summary: "Attendance recovery class prediction algorithm" } },
        "/api/marks": {
          get: { summary: "List student academic marks" },
          post: { summary: "Add subject mark record" },
        },
        "/api/marks/analytics": { get: { summary: "DSA marks analytics (high, low, avg, quick sort distribution)" } },
        "/api/notes": { get: { summary: "List and search smart notes" }, post: { summary: "Create note" } },
        "/api/notes/upload": { post: { summary: "Upload study file (PDF/Image)" } },
        "/api/study/session": { post: { summary: "Save completed Pomodoro study session" } },
        "/api/study/statistics": { get: { summary: "Daily, weekly, monthly study analytics" } },
        "/api/goals": { get: { summary: "List study goals" }, post: { summary: "Create goal" } },
        "/api/calendar": { get: { summary: "Chronological calendar events" }, post: { summary: "Add event" } },
        "/api/analytics/productivity": { get: { summary: "Calculate 0-100 productivity score and factors" } },
        "/api/ai/ask": { post: { summary: "Gemini AI Academic Tutor & Topic Explanation" } },
        "/api/ai/summarize": { post: { summary: "AI Notes Summarizer" } },
        "/api/ai/quiz": { post: { summary: "AI Practice Quiz Generator (MCQs, True/False, Short Answer)" } },
        "/api/ai/study-plan": { post: { summary: "AI Adaptive 7-Day Study Plan" } },
        "/api/ai/rag-search": { post: { summary: "Cosine Similarity Vector Note Retrieval + Context Answer" } },
      },
    });
  });

  // ==========================================
  // VITE DEV MIDDLEWARE / STATIC PRODUCTION
  // ==========================================
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Smart Student Companion full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
