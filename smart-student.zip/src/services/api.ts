import {
  User,
  Assignment,
  AttendanceRecord,
  AttendanceSummary,
  MarkRecord,
  MarksAnalytics,
  Note,
  StudyGoal,
  StudyStats,
  CalendarEvent,
  NotificationItem,
  ProductivityData,
  UrgentItem,
} from "../types";

const TOKEN_KEY = "ssc_auth_token";

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeStoredToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  const token = getStoredToken();
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  if (!headers.has("Content-Type") && !(options.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || data.message || "Request failed with status " + response.status);
  }

  return data;
}

export const api = {
  auth: {
    login: async (credentials: { email: string; password: string }) => {
      const res = await request<{ message: string; token: string; user: User }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(credentials),
      });
      setStoredToken(res.token);
      return res;
    },
    register: async (payload: { name: string; email: string; password: string; course: string; year?: string; college?: string }) => {
      const res = await request<{ message: string; token: string; user: User }>("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      setStoredToken(res.token);
      return res;
    },
    me: async () => {
      return request<{ user: User }>("/api/auth/me");
    },
    updateProfile: async (data: Partial<User>) => {
      return request<{ message: string; user: User }>("/api/auth/profile", {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },
    changePassword: async (passwords: { currentPassword: string; newPassword: string }) => {
      return request<{ message: string }>("/api/auth/change-password", {
        method: "POST",
        body: JSON.stringify(passwords),
      });
    },
  },

  assignments: {
    list: async (params?: { status?: string; priority?: string; subject?: string; sortBy?: string; search?: string; useAlgorithm?: string }) => {
      const query = new URLSearchParams(params as Record<string, string>).toString();
      return request<{ assignments: Assignment[]; total: number; dsaMetrics: any }>(`/api/assignments?${query}`);
    },
    get: async (id: string) => {
      return request<{ assignment: Assignment }>(`/api/assignments/${id}`);
    },
    create: async (data: Partial<Assignment>) => {
      return request<{ assignment: Assignment; message: string }>("/api/assignments", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    update: async (id: string, data: Partial<Assignment>) => {
      return request<{ assignment: Assignment; message: string }>(`/api/assignments/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },
    updateStatus: async (id: string, status: string) => {
      return request<{ assignment: Assignment }>(`/api/assignments/${id}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
    },
    delete: async (id: string) => {
      return request<{ message: string }>(`/api/assignments/${id}`, {
        method: "DELETE",
      });
    },
    getUrgentHeap: async () => {
      return request<{ urgentAssignments: UrgentItem[]; heapMetrics: any }>("/api/dsa/heap-urgent");
    },
  },

  attendance: {
    list: async () => {
      return request<{
        attendance: AttendanceRecord[];
        summary: AttendanceSummary;
        lookupComplexity: any;
      }>("/api/attendance");
    },
    upsert: async (data: { subject: string; present: number; total: number }) => {
      return request<{ attendance: AttendanceRecord; message: string }>("/api/attendance", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    delete: async (id: string) => {
      return request<{ message: string }>(`/api/attendance/${id}`, {
        method: "DELETE",
      });
    },
    predict: async (target = 75) => {
      return request<{ predictions: any[]; formula: string; complexity: string }>(`/api/attendance/prediction?target=${target}`);
    },
  },

  marks: {
    list: async () => {
      return request<{ marks: MarkRecord[] }>("/api/marks");
    },
    create: async (data: Partial<MarkRecord>) => {
      return request<{ mark: MarkRecord; message: string }>("/api/marks", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    delete: async (id: string) => {
      return request<{ message: string }>(`/api/marks/${id}`, {
        method: "DELETE",
      });
    },
    analytics: async () => {
      return request<MarksAnalytics>("/api/marks/analytics");
    },
  },

  notes: {
    list: async (params?: { search?: string; subject?: string; tag?: string }) => {
      const query = new URLSearchParams(params as Record<string, string>).toString();
      return request<{ notes: Note[] }>(`/api/notes?${query}`);
    },
    create: async (data: Partial<Note>) => {
      return request<{ note: Note; message: string }>("/api/notes", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    update: async (id: string, data: Partial<Note>) => {
      return request<{ note: Note; message: string }>(`/api/notes/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },
    delete: async (id: string) => {
      return request<{ message: string }>(`/api/notes/${id}`, {
        method: "DELETE",
      });
    },
    uploadFile: async (formData: FormData) => {
      return request<{ fileUrl: string; fileName: string; size: number }>("/api/notes/upload", {
        method: "POST",
        body: formData,
      });
    },
  },

  study: {
    recordSession: async (data: { subject: string; durationMinutes: number; notes?: string; completed?: boolean }) => {
      return request<{ session: any; message: string }>("/api/study/session", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    statistics: async () => {
      return request<StudyStats>("/api/study/statistics");
    },
  },

  goals: {
    list: async () => {
      return request<{ goals: StudyGoal[] }>("/api/goals");
    },
    create: async (data: Partial<StudyGoal>) => {
      return request<{ goal: StudyGoal; message: string }>("/api/goals", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    update: async (id: string, data: Partial<StudyGoal>) => {
      return request<{ goal: StudyGoal; message: string }>(`/api/goals/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
    },
    delete: async (id: string) => {
      return request<{ message: string }>(`/api/goals/${id}`, {
        method: "DELETE",
      });
    },
  },

  calendar: {
    list: async () => {
      return request<{ events: CalendarEvent[] }>("/api/calendar");
    },
    create: async (data: Partial<CalendarEvent>) => {
      return request<{ event: CalendarEvent; message: string }>("/api/calendar", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    delete: async (id: string) => {
      return request<{ message: string }>(`/api/calendar/${id}`, {
        method: "DELETE",
      });
    },
  },

  notifications: {
    list: async () => {
      return request<{ notifications: NotificationItem[]; unreadCount: number }>("/api/notifications");
    },
    markAsRead: async (id: string) => {
      return request<{ notification: NotificationItem }>(`/api/notifications/${id}/read`, {
        method: "PATCH",
      });
    },
  },

  analytics: {
    productivity: async () => {
      return request<ProductivityData>("/api/analytics/productivity");
    },
  },

  dsa: {
    prerequisitesGraph: async () => {
      return request<{ topologicalOrder: string[]; hasCycle: boolean; complexity: any; edges: { from: string; to: string }[] }>("/api/dsa/prerequisites-graph");
    },
  },

  ai: {
    ask: async (prompt: string, context?: string) => {
      return request<{ answer: string }>("/api/ai/ask", {
        method: "POST",
        body: JSON.stringify({ prompt, context }),
      });
    },
    summarize: async (title: string, content: string) => {
      return request<{ summary: string }>("/api/ai/summarize", {
        method: "POST",
        body: JSON.stringify({ title, content }),
      });
    },
    quiz: async (topicOrContent: string) => {
      return request<{
        quiz: {
          mcqs: { question: string; options: string[]; correctIndex: number; explanation: string }[];
          trueFalse: { statement: string; isTrue: boolean; explanation: string }[];
          shortQuestions: { question: string; modelAnswer: string }[];
        };
      }>("/api/ai/quiz", {
        method: "POST",
        body: JSON.stringify({ topicOrContent }),
      });
    },
    studyPlan: async (availableHoursPerDay = 3) => {
      return request<{
        plan: {
          weeklySchedule: { day: string; blocks: { timeSlot: string; subject: string; task: string; focusType: string }[] }[];
          recommendations: string[];
        };
      }>("/api/ai/study-plan", {
        method: "POST",
        body: JSON.stringify({ availableHoursPerDay }),
      });
    },
    ragSearch: async (query: string) => {
      return request<{
        answer: string;
        retrievedChunks: { id: string; title: string; subject: string; similarity: number }[];
        algorithmMetrics: any;
      }>("/api/ai/rag-search", {
        method: "POST",
        body: JSON.stringify({ query }),
      });
    },
  },
};
