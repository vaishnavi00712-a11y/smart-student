import React, { useState, useEffect } from "react";
import {
  UserCheck,
  Plus,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  TrendingUp,
  Percent,
  Trash2,
  Edit2,
  X,
  Calculator,
  ShieldCheck,
} from "lucide-react";
import { AttendanceRecord, AttendanceSummary } from "../types";
import { api } from "../services/api";

export const AttendanceView: React.FC = () => {
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [summary, setSummary] = useState<AttendanceSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Target percentage slider for simulation
  const [targetPercentage, setTargetPercentage] = useState(75);

  // Upsert modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formSubject, setFormSubject] = useState("");
  const [formPresent, setFormPresent] = useState(0);
  const [formTotal, setFormTotal] = useState(0);

  const fetchAttendance = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.attendance.list();
      setAttendance(res.attendance);
      setSummary(res.summary);
    } catch (err) {
      console.error(err);
      setError("Failed to load attendance records.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAttendance();
  }, []);

  const handleQuickIncrement = async (record: AttendanceRecord, isPresent: boolean) => {
    const nextPresent = isPresent ? record.present + 1 : record.present;
    const nextTotal = record.total + 1;

    try {
      await api.attendance.upsert({
        subject: record.subject,
        present: nextPresent,
        total: nextTotal,
      });
      fetchAttendance();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Remove attendance tracking for this subject?")) return;
    try {
      await api.attendance.delete(id);
      fetchAttendance();
    } catch (err) {
      console.error(err);
    }
  };

  const handleOpenUpsert = (record?: AttendanceRecord) => {
    if (record) {
      setFormSubject(record.subject);
      setFormPresent(record.present);
      setFormTotal(record.total);
    } else {
      setFormSubject("");
      setFormPresent(30);
      setFormTotal(35);
    }
    setIsModalOpen(true);
  };

  const handleSaveUpsert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formSubject || formTotal <= 0 || formPresent < 0) return;
    if (formPresent > formTotal) {
      alert("Attended classes cannot exceed total classes.");
      return;
    }

    try {
      await api.attendance.upsert({
        subject: formSubject.trim(),
        present: Number(formPresent),
        total: Number(formTotal),
      });
      setIsModalOpen(false);
      fetchAttendance();
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Error saving attendance");
    }
  };

  // Re-calculate prediction dynamically when user slides target percentage
  const getDynamicPrediction = (present: number, total: number) => {
    if (total === 0) return { classesNeeded: 0, classesCanMiss: 0, pct: 100 };
    const pct = Number(((present / total) * 100).toFixed(2));
    let needed = 0;
    if (pct < targetPercentage) {
      const num = targetPercentage * total - 100 * present;
      const den = 100 - targetPercentage;
      needed = Math.ceil(num / den);
    }
    let canMiss = 0;
    if (pct >= targetPercentage) {
      canMiss = Math.floor((100 * present - targetPercentage * total) / targetPercentage);
    }
    return { classesNeeded: Math.max(0, needed), classesCanMiss: Math.max(0, canMiss), pct };
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <UserCheck className="w-6 h-6 text-emerald-600" />
            <span>Attendance Tracker & Predictive Recovery</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Subject-wise percentage tracking and recovery predictions to help you stay eligible for exams.
          </p>
        </div>

        <button
          onClick={() => handleOpenUpsert()}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Record Attendance (Upsert)</span>
        </button>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Overall Attendance</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{summary?.overallPercentage || 0}%</span>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded ${
                (summary?.overallPercentage || 0) >= 75
                  ? "bg-emerald-100 text-emerald-800"
                  : "bg-rose-100 text-rose-800"
              }`}
            >
              {(summary?.overallPercentage || 0) >= 75 ? "Safe Overall" : "Shortage Warning"}
            </span>
          </div>
          <p className="mt-2 text-xs text-slate-500">
            Across {summary?.totalSubjects || 0} enrolled academic subjects.
          </p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Safe Subjects (&ge; 75%)</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-600">{summary?.safeCount || 0}</span>
            <span className="text-xs text-slate-500">of {summary?.totalSubjects || 0} subjects</span>
          </div>
          <p className="mt-2 text-xs text-slate-500">Eligible for end-semester examinations.</p>
        </div>

        <div className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Shortage Warnings (&lt; 75%)</span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-rose-600">{summary?.shortageCount || 0}</span>
            <span className="text-xs text-slate-500">needs immediate recovery</span>
          </div>
          <p className="mt-2 text-xs text-slate-500">Calculated via mathematical prediction formula.</p>
        </div>
      </div>

      {/* Target Simulation Bar */}
      <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Calculator className="w-5 h-5 text-emerald-600" />
          <h3 className="text-sm font-bold text-slate-800">Recovery Target Simulator</h3>
        </div>

        <div className="flex items-center gap-3 bg-slate-50 px-4 py-2 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-600 font-semibold">Simulate Target:</span>
          <input
            type="range"
            min="65"
            max="90"
            step="1"
            value={targetPercentage}
            onChange={(e) => setTargetPercentage(Number(e.target.value))}
            className="w-28 accent-emerald-500 cursor-pointer"
          />
          <span className="text-xs font-mono font-bold text-emerald-600 w-10 text-right">
            {targetPercentage}%
          </span>
        </div>
      </div>

      {/* Subject Attendance Cards */}
      {loading ? (
        <div className="p-12 text-center text-xs text-slate-400">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          Loading subject attendance and running predictions...
        </div>
      ) : attendance.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 space-y-3">
          <UserCheck className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">No attendance tracked yet</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Click "Record Attendance" above to register your first subject.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {attendance.map((record) => {
            const pred = getDynamicPrediction(record.present, record.total);
            const isSafe = pred.pct >= targetPercentage;

            return (
              <div
                key={record.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-all space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{record.subject}</h4>
                    <span className="text-xs text-slate-500">
                      Attended: <strong className="text-slate-800">{record.present}</strong> / {record.total} classes
                    </span>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-lg font-extrabold ${
                        isSafe ? "text-emerald-600" : "text-rose-600"
                      }`}
                    >
                      {pred.pct}%
                    </span>
                    <span
                      className={`block text-[10px] font-bold px-2 py-0.5 rounded mt-0.5 ${
                        isSafe ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"
                      }`}
                    >
                      {isSafe ? "Safe Zone" : "Shortage Warning"}
                    </span>
                  </div>
                </div>

                {/* Visual Progress Bar */}
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${
                      isSafe ? "bg-emerald-500" : "bg-rose-500"
                    }`}
                    style={{ width: `${Math.min(100, pred.pct)}%` }}
                  />
                </div>

                {/* Prediction Result Box */}
                <div
                  className={`p-3 rounded-lg text-xs flex items-start gap-2.5 ${
                    !isSafe
                      ? "bg-rose-50/80 border border-rose-200/80 text-rose-900"
                      : "bg-emerald-50/80 border border-emerald-200/80 text-emerald-900"
                  }`}
                >
                  {!isSafe ? (
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  ) : (
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-0.5">
                    {!isSafe ? (
                      <>
                        <span className="font-bold text-rose-900">
                          Shortage Alert! You need to attend {pred.classesNeeded} consecutive classes
                        </span>
                        <p className="text-[11px] text-rose-700">
                          Attend the next {pred.classesNeeded} classes without missing any to restore attendance to {targetPercentage}%.
                        </p>
                      </>
                    ) : (
                      <>
                        <span className="font-bold text-emerald-900">
                          Safe Standing! You can safely miss up to {pred.classesCanMiss} classes
                        </span>
                        <p className="text-[11px] text-emerald-700">
                          Your attendance will remain at or above {targetPercentage}% even if you miss {pred.classesCanMiss} upcoming lectures.
                        </p>
                      </>
                    )}
                  </div>
                </div>

                {/* Quick Increment Controls & Card Actions */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px] font-medium">Quick Log:</span>
                    <button
                      onClick={() => handleQuickIncrement(record, true)}
                      className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-lg transition-colors"
                      title="Add 1 present class"
                    >
                      +1 Present
                    </button>
                    <button
                      onClick={() => handleQuickIncrement(record, false)}
                      className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-lg transition-colors"
                      title="Add 1 missed class"
                    >
                      +1 Absent
                    </button>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenUpsert(record)}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                      title="Edit values"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(record.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title="Delete record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upsert Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                Attendance Upsert Record (user_id + subject)
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUpsert} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Subject Name *
                </label>
                <input
                  type="text"
                  required
                  value={formSubject}
                  onChange={(e) => setFormSubject(e.target.value)}
                  placeholder="e.g. Operating Systems"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  If this subject already exists, it will UPDATE. Otherwise, it will INSERT.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Present Classes *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formPresent}
                    onChange={(e) => setFormPresent(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Total Classes *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formTotal}
                    onChange={(e) => setFormTotal(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20"
                >
                  Save (Upsert)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
