import React, { useState, useEffect, useRef } from "react";
import {
  Menu,
  Bell,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Info,
  Calendar as CalendarIcon,
} from "lucide-react";
import { User, NotificationItem } from "../types";
import { api } from "../services/api";

interface NavbarProps {
  user: User | null;
  onToggleSidebar: () => void;
  onOpenAI: () => void;
  productivityScore?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onToggleSidebar,
  onOpenAI,
  productivityScore = 82,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  // Time-aware greeting
  const [greeting, setGreeting] = useState("Good Morning");
  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting("Good Morning");
    else if (hour < 18) setGreeting("Good Afternoon");
    else setGreeting("Good Evening");
  }, []);

  // Fetch notifications
  const loadNotifications = async () => {
    try {
      const res = await api.notifications.list();
      setNotifications(res.notifications);
      setUnreadCount(res.unreadCount);
    } catch {
      // ignore unauthenticated
    }
  };

  useEffect(() => {
    if (user) {
      loadNotifications();
    }
  }, [user]);

  // Click outside listener for notifications dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleMarkAsRead = async (id: string) => {
    try {
      await api.notifications.markAsRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
      setUnreadCount((c) => Math.max(0, c - 1));
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <header className="sticky top-0 z-30 h-16 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 flex items-center justify-between">
      {/* Left section: Hamburger & Greeting */}
      <div className="flex items-center gap-3 sm:gap-4">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          aria-label="Toggle navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>
              {greeting}, {user ? user.name.split(" ")[0] : "Student"}
            </span>
            <span className="inline-block animate-wave origin-bottom-right">👋</span>
          </h1>
          <p className="hidden sm:block text-xs text-slate-500 font-medium">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              month: "short",
              day: "numeric",
            })}{" "}
            • {user?.year || "Current Semester"}
          </p>
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* Productivity Badge */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs font-semibold">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span className="text-slate-600">Productivity:</span>
          <span className="text-slate-900 font-bold">{productivityScore}/100</span>
        </div>

        {/* AI Assistant Quick Trigger */}
        <button
          onClick={onOpenAI}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-50 to-cyan-50 border border-indigo-200/80 text-indigo-700 hover:border-indigo-300 font-semibold text-xs transition-all shadow-xs"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-spin-slow" />
          <span className="hidden sm:inline">Ask AI Tutor</span>
          <span className="sm:hidden">AI</span>
        </button>

        {/* Notifications Dropdown */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setShowNotifMenu(!showNotifMenu)}
            className="relative p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center ring-2 ring-white">
                {unreadCount}
              </span>
            )}
          </button>

          {showNotifMenu && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                <div className="font-semibold text-xs text-slate-800 flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-slate-500" />
                  <span>Academic Alerts & Reminders</span>
                </div>
                {unreadCount > 0 && (
                  <span className="text-[11px] font-medium text-cyan-700 bg-cyan-50 px-2 py-0.5 rounded-full border border-cyan-200">
                    {unreadCount} unread
                  </span>
                )}
              </div>

              <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    No notifications at this time.
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => !n.read && handleMarkAsRead(n.id)}
                      className={`p-3 text-left transition-colors cursor-pointer hover:bg-slate-50/80 ${
                        !n.read ? "bg-cyan-50/40" : ""
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        {n.type === "warning" ? (
                          <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                        ) : n.type === "success" ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                        ) : n.type === "reminder" ? (
                          <CalendarIcon className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                        ) : (
                          <Info className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-semibold text-slate-900 flex items-center justify-between">
                            <span className="truncate">{n.title}</span>
                            {!n.read && (
                              <span className="w-2 h-2 rounded-full bg-cyan-500 shrink-0" />
                            )}
                          </div>
                          <p className="text-[11px] text-slate-600 mt-0.5 line-clamp-2">
                            {n.message}
                          </p>
                          <span className="text-[10px] text-slate-400 mt-1 block">
                            {new Date(n.createdAt).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
