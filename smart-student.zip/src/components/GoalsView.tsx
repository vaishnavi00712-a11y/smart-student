import React, { useState, useEffect } from "react";
import {
  Target,
  Plus,
  CheckCircle2,
  Calendar,
  Sparkles,
  Trash2,
  X,
  Award,
} from "lucide-react";
import confetti from "canvas-confetti";
import { StudyGoal } from "../types";
import { api } from "../services/api";

export const GoalsView: React.FC = () => {
  const [goals, setGoals] = useState<StudyGoal[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form
  const [formTitle, setFormTitle] = useState("");
  const [formSubject, setFormSubject] = useState("Database Management Systems");
  const [formTargetHours, setFormTargetHours] = useState(15);
  const [formDeadline, setFormDeadline] = useState("");

  const fetchGoals = async () => {
    setLoading(true);
    try {
      const res = await api.goals.list();
      setGoals(res.goals);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGoals();
  }, []);

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const handleIncrementHours = async (goal: StudyGoal, increment: number) => {
    const nextCompleted = Math.min(goal.targetHours, goal.completedHours + increment);
    const isNowComplete = nextCompleted >= goal.targetHours;

    if (isNowComplete && goal.status !== "completed") {
      triggerConfetti();
    }

    try {
      await api.goals.update(goal.id, {
        completedHours: nextCompleted,
      });
      fetchGoals();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Remove this study goal?")) return;
    try {
      await api.goals.delete(id);
      fetchGoals();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || formTargetHours <= 0) return;

    try {
      await api.goals.create({
        title: formTitle,
        subject: formSubject,
        targetHours: Number(formTargetHours),
        completedHours: 0,
        deadline: formDeadline ? new Date(formDeadline).toISOString() : new Date().toISOString(),
      });
      setIsModalOpen(false);
      setFormTitle("");
      fetchGoals();
    } catch (err: any) {
      console.error(err);
      alert(err?.message || "Error creating goal");
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Target className="w-6 h-6 text-purple-600" />
            <span>Academic Study Goals & Milestone Tracker</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Weekly target hours, subject mastery targets, and celebration rewards upon completion.
          </p>
        </div>

        <button
          onClick={() => {
            const nextWeek = new Date();
            nextWeek.setDate(nextWeek.getDate() + 7);
            setFormDeadline(nextWeek.toISOString().split("T")[0]);
            setIsModalOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Study Goal</span>
        </button>
      </div>

      {/* Goal Cards */}
      {loading ? (
        <div className="p-12 text-center text-xs text-slate-400">
          <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          Loading study targets...
        </div>
      ) : goals.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 space-y-3">
          <Target className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">No active goals found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Set a target number of study hours for your upcoming exam or semester.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {goals.map((goal) => {
            const isCompleted = goal.status === "completed" || goal.completedHours >= goal.targetHours;
            const pct = Math.min(100, Math.round((goal.completedHours / goal.targetHours) * 100));

            return (
              <div
                key={goal.id}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 ${
                  isCompleted
                    ? "bg-purple-50/50 border-purple-200"
                    : "bg-white border-slate-200 shadow-xs hover:border-slate-300"
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 bg-purple-100/60 px-2 py-0.5 rounded">
                      {goal.subject}
                    </span>
                    {isCompleted ? (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed!
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-slate-500">
                        {goal.completedHours} / {goal.targetHours} hrs
                      </span>
                    )}
                  </div>

                  <h3 className="text-sm font-bold text-slate-900">{goal.title}</h3>

                  {/* Progress Bar */}
                  <div className="space-y-1 pt-1">
                    <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                      <span>Progress</span>
                      <span className="font-bold text-purple-700">{pct}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full transition-all duration-300 ${
                          isCompleted ? "bg-emerald-500" : "bg-purple-600"
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400 flex items-center gap-1 pt-1">
                    <Calendar className="w-3 h-3" />
                    <span>Target deadline: {new Date(goal.deadline).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {!isCompleted && (
                      <>
                        <button
                          onClick={() => handleIncrementHours(goal, 0.5)}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-purple-50 hover:text-purple-700 text-slate-700 text-xs font-semibold transition-colors"
                          title="Log 30 minutes"
                        >
                          +0.5h
                        </button>
                        <button
                          onClick={() => handleIncrementHours(goal, 1)}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-purple-50 hover:text-purple-700 text-slate-700 text-xs font-semibold transition-colors"
                          title="Log 1 hour"
                        >
                          +1h
                        </button>
                      </>
                    )}
                  </div>

                  <button
                    onClick={() => handleDelete(goal.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                    title="Delete goal"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Create Academic Study Goal</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Goal Objective *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Master Graph Theory & Flow Networks"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Target Course
                </label>
                <select
                  value={formSubject}
                  onChange={(e) => setFormSubject(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                >
                  <option value="Database Management Systems">Database Management Systems</option>
                  <option value="Operating Systems">Operating Systems</option>
                  <option value="Computer Networks">Computer Networks</option>
                  <option value="Design & Analysis of Algorithms">Design & Analysis of Algorithms</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Target Hours *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formTargetHours}
                    onChange={(e) => setFormTargetHours(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Target Deadline
                  </label>
                  <input
                    type="date"
                    required
                    value={formDeadline}
                    onChange={(e) => setFormDeadline(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-600/20"
                >
                  Create Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
