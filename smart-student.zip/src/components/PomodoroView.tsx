import React, { useState, useEffect, useRef } from "react";
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  Coffee,
  BookOpen,
  Volume2,
  VolumeX,
  CheckCircle,
  BarChart3,
  Calendar,
} from "lucide-react";
import { StudyStats } from "../types";
import { api } from "../services/api";

export const PomodoroView: React.FC = () => {
  // Timer Mode: 'study' (25m), 'break' (5m), 'custom'
  const [mode, setMode] = useState<"study" | "break" | "custom">("study");
  const [customMinutes, setCustomMinutes] = useState(45);
  const [selectedSubject, setSelectedSubject] = useState("Database Management Systems");
  const [sessionNotes, setSessionNotes] = useState("");

  // Durations in seconds
  const getInitialSeconds = (m: "study" | "break" | "custom") => {
    if (m === "study") return 25 * 60;
    if (m === "break") return 5 * 60;
    return customMinutes * 60;
  };

  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Statistics
  const [stats, setStats] = useState<StudyStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  // Web Audio Context synthesizer for completion bell
  const playChime = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.3); // A5
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.2);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 1.2);
    } catch {
      // audio context may require user interaction
    }
  };

  const fetchStats = async () => {
    try {
      const res = await api.study.statistics();
      setStats(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingStats(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  // Timer Tick
  useEffect(() => {
    let interval: any = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      playChime();
      // Record completed study session if in study/custom mode
      if (mode !== "break") {
        const duration = mode === "study" ? 25 : customMinutes;
        api.study
          .recordSession({
            subject: selectedSubject,
            durationMinutes: duration,
            notes: sessionNotes || "Completed Pomodoro focus session",
            completed: true,
          })
          .then(() => fetchStats())
          .catch(console.error);
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, mode]);

  const handleModeChange = (newMode: "study" | "break" | "custom") => {
    setMode(newMode);
    setIsRunning(false);
    setTimeLeft(getInitialSeconds(newMode));
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(getInitialSeconds(mode));
  };

  const totalTimeForMode =
    mode === "study" ? 25 * 60 : mode === "break" ? 5 * 60 : customMinutes * 60;
  const progressPercent = ((totalTimeForMode - timeLeft) / totalTimeForMode) * 100;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Timer className="w-6 h-6 text-rose-600" />
            <span>Pomodoro Focus Timer & Study Analytics</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            25-min deep focus intervals, relaxation breaks, auto-logging to MongoDB, and daily/weekly consistency charts.
          </p>
        </div>

        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold self-start sm:self-auto"
        >
          {soundEnabled ? (
            <>
              <Volume2 className="w-4 h-4 text-emerald-600" />
              <span>Bell Sound Enabled</span>
            </>
          ) : (
            <>
              <VolumeX className="w-4 h-4 text-slate-400" />
              <span>Muted</span>
            </>
          )}
        </button>
      </div>

      {/* Main Grid: Timer on Left, Statistics on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Timer Card (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs flex flex-col items-center justify-between text-center space-y-6">
          {/* Mode Selector */}
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => handleModeChange("study")}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                mode === "study"
                  ? "bg-white text-rose-600 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Study Focus (25m)</span>
            </button>
            <button
              onClick={() => handleModeChange("break")}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                mode === "break"
                  ? "bg-white text-emerald-600 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Coffee className="w-3.5 h-3.5" />
              <span>Break (5m)</span>
            </button>
            <button
              onClick={() => handleModeChange("custom")}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                mode === "custom"
                  ? "bg-white text-indigo-600 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Custom ({customMinutes}m)
            </button>
          </div>

          {/* Circular Progress & Display */}
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center">
            {/* SVG circle */}
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="44"
                className="stroke-slate-100"
                strokeWidth="6"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="44"
                className={`transition-all duration-1000 ${
                  mode === "break" ? "stroke-emerald-500" : "stroke-rose-500"
                }`}
                strokeWidth="6"
                strokeDasharray={2 * Math.PI * 44}
                strokeDashoffset={2 * Math.PI * 44 * (1 - progressPercent / 100)}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>

            {/* Inner text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl sm:text-6xl font-black text-slate-900 tracking-tight font-mono">
                {formattedTime}
              </span>
              <span className="text-xs font-semibold text-slate-400 mt-2 uppercase tracking-wider">
                {isRunning ? (mode === "break" ? "Break in progress" : "Focusing...") : "Paused"}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`px-8 py-3 rounded-xl font-bold text-sm flex items-center gap-2 text-white shadow-lg transition-all ${
                isRunning
                  ? "bg-amber-500 hover:bg-amber-600 shadow-amber-500/25"
                  : mode === "break"
                  ? "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/25"
                  : "bg-rose-600 hover:bg-rose-500 shadow-rose-600/25"
              }`}
            >
              {isRunning ? (
                <>
                  <Pause className="w-5 h-5" />
                  <span>Pause Timer</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5" />
                  <span>Start Focus Session</span>
                </>
              )}
            </button>

            <button
              onClick={handleReset}
              className="p-3 rounded-xl border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition-colors"
              title="Reset timer"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
          </div>

          {/* Subject and Focus Notes Input */}
          <div className="w-full max-w-md pt-4 border-t border-slate-100 space-y-3 text-left">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Focus Subject
              </label>
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              >
                <option value="Database Management Systems">Database Management Systems</option>
                <option value="Operating Systems">Operating Systems</option>
                <option value="Computer Networks">Computer Networks</option>
                <option value="Design & Analysis of Algorithms">Design & Analysis of Algorithms</option>
                <option value="Theory of Computation">Theory of Computation</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Session Target / Goal
              </label>
              <input
                type="text"
                value={sessionNotes}
                onChange={(e) => setSessionNotes(e.target.value)}
                placeholder="e.g. Master Bellman-Ford shortest path algorithm"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
              />
            </div>
          </div>
        </div>

        {/* Study Analytics Cards (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* 3 Metric cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-4 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Today</span>
              <div className="text-xl font-extrabold text-slate-900 mt-1">
                {stats?.dailyStudyHours || 0}h
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase">This Week</span>
              <div className="text-xl font-extrabold text-rose-600 mt-1">
                {stats?.weeklyStudyHours || 0}h
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white border border-slate-200 text-center shadow-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Month</span>
              <div className="text-xl font-extrabold text-slate-900 mt-1">
                {stats?.monthlyStudyHours || 0}h
              </div>
            </div>
          </div>

          {/* Subject Study Breakdown */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              <span>Subject Hours Distribution</span>
            </h4>

            <div className="space-y-2.5">
              {stats?.subjectBreakdown && Object.keys(stats.subjectBreakdown).length > 0 ? (
                Object.entries(stats.subjectBreakdown).map(([subj, hours]) => (
                  <div key={subj} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-700 font-medium truncate max-w-[200px]">
                        {subj}
                      </span>
                      <span className="font-mono font-bold text-slate-900">{hours}h</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-rose-500 h-1.5 rounded-full"
                        style={{ width: `${Math.min(100, (Number(hours) / 10) * 100)}%` }}
                      />
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-xs text-slate-400 py-3 text-center">
                  Start your first Pomodoro session to view breakdown.
                </div>
              )}
            </div>
          </div>

          {/* Recent Completed Sessions */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>Recent Completed Sessions</span>
            </h4>

            <div className="space-y-2 max-h-56 overflow-y-auto">
              {stats?.recentSessions && stats.recentSessions.length > 0 ? (
                stats.recentSessions.slice(0, 5).map((s, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <strong className="text-slate-800 block truncate max-w-[180px]">
                        {s.subject}
                      </strong>
                      <span className="text-[10px] text-slate-400">
                        {new Date(s.endTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        {s.notes && ` • ${s.notes}`}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[11px]">
                      +{s.durationMinutes}m
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-xs text-slate-400 py-3 text-center">
                  No completed sessions yet today.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
