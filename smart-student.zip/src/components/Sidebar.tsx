import React from "react";
import {
  LayoutDashboard,
  CheckSquare,
  UserCheck,
  GraduationCap,
  FileText,
  Timer,
  Target,
  Calendar,
  Sparkles,
  BookOpen,
  LogOut,
  User as UserIcon,
} from "lucide-react";
import { User } from "../types";

export type NavTab =
  | "dashboard"
  | "assignments"
  | "attendance"
  | "marks"
  | "notes"
  | "pomodoro"
  | "goals"
  | "calendar"
  | "ai-assistant";

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  user: User | null;
  onOpenProfile: () => void;
  onLogout: () => void;
  isOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  user,
  onOpenProfile,
  onLogout,
  isOpen,
  onCloseMobile,
}) => {
  const menuItems: { id: NavTab; label: string; icon: React.FC<{ className?: string }>; badge?: string }[] = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "assignments", label: "Assignments", icon: CheckSquare },
    { id: "attendance", label: "Attendance", icon: UserCheck },
    { id: "marks", label: "Marks Analyzer", icon: GraduationCap },
    { id: "notes", label: "Smart Notes", icon: FileText },
    { id: "pomodoro", label: "Study Timer", icon: Timer },
    { id: "goals", label: "Study Goals", icon: Target },
    { id: "calendar", label: "Calendar", icon: Calendar },
    { id: "ai-assistant", label: "AI Assistant", icon: Sparkles, badge: "Gemini" },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 text-slate-100 flex flex-col border-r border-slate-800 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center px-6 border-b border-slate-800/80 gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-500 flex items-center justify-center text-white font-bold shadow-md shadow-cyan-500/20">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-base tracking-tight text-white flex items-center gap-1.5">
              <span>Smart Student</span>
            </div>
            <div className="text-[11px] text-slate-400 font-medium">Academic Productivity</div>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Core Modules
          </div>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const active = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                  active
                    ? "bg-cyan-500/15 text-cyan-400 border border-cyan-500/30"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${active ? "text-cyan-400" : "text-slate-400"}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-semibold ${
                      active
                        ? "bg-cyan-400/20 text-cyan-300"
                        : "bg-slate-800 text-slate-400 border border-slate-700"
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User Account / Footer */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
          {user ? (
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-800/50 border border-slate-800">
              <button
                onClick={onOpenProfile}
                className="flex items-center gap-2.5 text-left hover:opacity-85 transition-opacity"
              >
                <div className="w-8 h-8 rounded-full bg-cyan-600/30 border border-cyan-500/40 flex items-center justify-center text-cyan-300 font-semibold text-xs overflow-hidden">
                  {user.avatarUrl ? (
                    <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" />
                  ) : (
                    user.name.slice(0, 2).toUpperCase()
                  )}
                </div>
                <div className="overflow-hidden">
                  <div className="text-xs font-semibold text-white truncate w-28">{user.name}</div>
                  <div className="text-[11px] text-slate-400 truncate w-28">{user.course}</div>
                </div>
              </button>
              <button
                onClick={onLogout}
                title="Sign out"
                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenProfile}
              className="w-full py-2 px-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs rounded-lg flex items-center justify-center gap-2 transition-colors"
            >
              <UserIcon className="w-4 h-4" />
              <span>Sign In / Demo</span>
            </button>
          )}
        </div>
      </aside>
    </>
  );
};
